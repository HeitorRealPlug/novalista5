anonasc = int(input('Digite o ano em que você nasceu:'))
if anonasc <= 2005:
    print('Você é maior de idade')
else:
    print('Você é menor de idade')