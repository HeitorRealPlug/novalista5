num1 = int(input('Digite o primeiro número:'))
num2 = int(input('Digite o segundo número:'))
if num1 > num2:
    print(num1, 'é o maior número')
else:
    print(num2, 'é o maior número')